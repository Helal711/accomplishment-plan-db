import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  getDocs,
  serverTimestamp,
  writeBatch,
  orderBy,
  runTransaction,
} from 'firebase/firestore';
import { db, auth } from './config';
import {
  TaskItem,
  AccountItem,
  StatusItem,
  CategoryItem,
  DEFAULT_ACCOUNTS,
  DEFAULT_STATUSES,
  DEFAULT_CATEGORIES,
} from '../types';

/**
 * Diagnostic logger that safely logs collection, operation, auth UID, and payload ownerUid.
 * Never logs credentials, tokens, or passwords.
 */
function logFirestoreOp(collectionName: string, operation: string, payloadOwnerUid?: string, docId?: string) {
  const currentAuthUid = auth.currentUser?.uid || 'UNAUTHENTICATED';
  console.log(
    `[Firestore Diagnostics] Collection: ${collectionName} | Operation: ${operation} | Auth UID: ${currentAuthUid} | Payload ownerUid: ${payloadOwnerUid || 'N/A'}${docId ? ` | Doc ID: ${docId}` : ''}`
  );
}

/**
 * Deterministically sorts tasks by taskNumber ASC, tie-breaker createdAt, tie-breaker id
 */
function sortTasksDeterministically(tasks: TaskItem[]): TaskItem[] {
  return [...tasks].sort((a, b) => {
    if (a.taskNumber !== b.taskNumber) {
      return a.taskNumber - b.taskNumber;
    }
    const aTime = a.createdAt?.seconds || 0;
    const bTime = b.createdAt?.seconds || 0;
    if (aTime !== bTime) {
      return aTime - bTime;
    }
    return (a.id || '').localeCompare(b.id || '');
  });
}

/**
 * Heal any gaps, duplicate numbers, or unassigned task numbers in the database.
 * Runs non-destructively in the background.
 */
export async function healTaskSerialNumbers(uid: string, monthYear: string, currentTasks: TaskItem[]): Promise<void> {
  if (!uid || currentTasks.length === 0) return;

  const sorted = sortTasksDeterministically(currentTasks);
  const needsReindex = sorted.some((t, index) => t.taskNumber !== index + 1);

  if (!needsReindex) return;

  console.log(`[Firestore Diagnostics] Healing task serial numbers for user ${uid} and month ${monthYear}...`);
  try {
    const batch = writeBatch(db);
    let changesCount = 0;

    sorted.forEach((task, index) => {
      const correctNumber = index + 1;
      if (task.taskNumber !== correctNumber && task.id) {
        const taskRef = doc(db, 'Tasks', task.id);
        batch.update(taskRef, {
          taskNumber: correctNumber,
          updatedAt: serverTimestamp(),
        });
        changesCount++;
      }
    });

    if (changesCount > 0) {
      await batch.commit();
      console.log(`[Firestore Diagnostics] Successfully healed ${changesCount} task serial numbers.`);
    }
  } catch (err) {
    console.warn('[Firestore Diagnostics] Serial number healing warning (deferred):', err);
  }
}

// Subscribe to tasks for user and specific month
export function subscribeToTasks(
  uid: string,
  monthYear: string,
  onUpdate: (tasks: TaskItem[]) => void,
  onError?: (error: Error) => void
): () => void {
  if (!uid) {
    onUpdate([]);
    return () => {};
  }

  logFirestoreOp('Tasks', 'subscribe', uid);

  const q = query(
    collection(db, 'Tasks'),
    where('ownerUid', '==', uid),
    where('monthYear', '==', monthYear)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: TaskItem[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ownerUid: data.ownerUid || uid,
          taskNumber: typeof data.taskNumber === 'number' && data.taskNumber > 0 ? data.taskNumber : 1,
          description: data.description || '',
          amount: data.amount || '',
          paymentMode: data.paymentMode || 'Cash',
          unit: data.unit || 'Unit-1',
          priority: data.priority || 'High',
          status: data.status || 'Draft Ready',
          expectedDate: data.expectedDate || '',
          accountName: data.accountName || 'Civil Maintenance',
          accountCode: data.accountCode || 'ACC-CM101',
          category: data.category || '',
          remarks: data.remarks || '',
          monthYear: data.monthYear || monthYear,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = sortTasksDeterministically(items);
      onUpdate(sorted);

      // Check if duplicate or non-sequential serial numbers exist in DB and heal them
      const hasDiscrepancy = sorted.some((t, idx) => t.taskNumber !== idx + 1);
      if (hasDiscrepancy && auth.currentUser?.uid === uid) {
        healTaskSerialNumbers(uid, monthYear, sorted);
      }
    },
    (err) => {
      console.error('[Firestore Diagnostics] Error subscribing to Tasks:', err);
      if (onError) onError(err);
    }
  );
}

// Subscribe to all accounts for user
export function subscribeToAccounts(
  uid: string,
  onUpdate: (accounts: AccountItem[]) => void
): () => void {
  if (!uid) {
    onUpdate([]);
    return () => {};
  }
  logFirestoreOp('Account_List', 'subscribe', uid);

  const q = query(
    collection(db, 'Account_List'),
    where('ownerUid', '==', uid)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: AccountItem[] = snapshot.docs.map((d) => ({
        id: d.id,
        ownerUid: d.data().ownerUid,
        accountName: d.data().accountName || '',
        accountCode: d.data().accountCode || '',
        createdAt: d.data().createdAt,
      }));
      items.sort((a, b) => a.accountName.localeCompare(b.accountName));
      onUpdate(items);
    },
    (err) => console.error('[Firestore Diagnostics] Error subscribing to accounts:', err)
  );
}

// Subscribe to all custom statuses for user
export function subscribeToStatuses(
  uid: string,
  onUpdate: (statuses: StatusItem[]) => void
): () => void {
  if (!uid) {
    onUpdate([]);
    return () => {};
  }
  logFirestoreOp('Status_List', 'subscribe', uid);

  const q = query(
    collection(db, 'Status_List'),
    where('ownerUid', '==', uid)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: StatusItem[] = snapshot.docs.map((d) => ({
        id: d.id,
        ownerUid: d.data().ownerUid,
        statusName: d.data().statusName || '',
        isDefault: !!d.data().isDefault,
        createdAt: d.data().createdAt,
      }));
      onUpdate(items);
    },
    (err) => console.error('[Firestore Diagnostics] Error subscribing to statuses:', err)
  );
}

// Subscribe to all categories for user
export function subscribeToCategories(
  uid: string,
  onUpdate: (categories: CategoryItem[]) => void
): () => void {
  if (!uid) {
    onUpdate([]);
    return () => {};
  }
  logFirestoreOp('Category_List', 'subscribe', uid);

  const q = query(
    collection(db, 'Category_List'),
    where('ownerUid', '==', uid)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CategoryItem[] = snapshot.docs.map((d) => ({
        id: d.id,
        ownerUid: d.data().ownerUid,
        categoryName: d.data().categoryName || '',
        createdAt: d.data().createdAt,
        updatedAt: d.data().updatedAt,
      }));
      items.sort((a, b) => a.categoryName.localeCompare(b.categoryName));
      onUpdate(items);
    },
    (err) => console.error('[Firestore Diagnostics] Error subscribing to categories:', err)
  );
}

/**
 * Get next sequential task number for a given user and month
 */
export async function getNextTaskNumber(uid: string, monthYear: string): Promise<number> {
  const q = query(
    collection(db, 'Tasks'),
    where('ownerUid', '==', uid),
    where('monthYear', '==', monthYear)
  );
  const snap = await getDocs(q);
  if (snap.empty) return 1;

  let maxNum = 0;
  snap.docs.forEach((d) => {
    const num = d.data().taskNumber;
    if (typeof num === 'number' && num > maxNum) {
      maxNum = num;
    }
  });

  return maxNum + 1;
}

// Add a new task with concurrency-safe sequential serial number
export async function addTask(task: Omit<TaskItem, 'id'>): Promise<string> {
  const currentAuthUid = auth.currentUser?.uid;
  if (!currentAuthUid) {
    throw new Error('Authentication required: Firebase user is not signed in.');
  }

  // Ensure ownerUid strictly matches authenticated user
  const validatedTask = {
    ...task,
    ownerUid: currentAuthUid,
  };

  // Determine next sequential number for this user and month
  const nextNum = await getNextTaskNumber(currentAuthUid, validatedTask.monthYear);
  const finalTaskNumber = typeof task.taskNumber === 'number' && task.taskNumber > 0 ? task.taskNumber : nextNum;

  logFirestoreOp('Tasks', 'create', currentAuthUid);

  const docRef = await addDoc(collection(db, 'Tasks'), {
    ...validatedTask,
    taskNumber: finalTaskNumber,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  logFirestoreOp('Tasks', 'create_success', currentAuthUid, docRef.id);
  return docRef.id;
}

// Update an existing task preserving serial number and ownerUid
export async function updateTask(
  taskId: string,
  updates: Partial<TaskItem>
): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  if (!currentAuthUid) {
    throw new Error('Authentication required: Firebase user is not signed in.');
  }

  logFirestoreOp('Tasks', 'update', currentAuthUid, taskId);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { id, ownerUid, taskNumber, ...dataToUpdate } = updates;
  const docRef = doc(db, 'Tasks', taskId);

  await updateDoc(docRef, {
    ...dataToUpdate,
    ownerUid: currentAuthUid,
    updatedAt: serverTimestamp(),
  });
}

/**
 * Delete task and sequentially renumber remaining tasks for that month
 */
export async function deleteTask(taskId: string, monthYear?: string, ownerUid?: string): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid || ownerUid;
  if (!currentAuthUid) {
    throw new Error('Authentication required to delete task.');
  }

  logFirestoreOp('Tasks', 'delete', currentAuthUid, taskId);

  // If monthYear is provided, renumber remaining tasks sequentially without gaps
  if (monthYear) {
    try {
      const q = query(
        collection(db, 'Tasks'),
        where('ownerUid', '==', currentAuthUid),
        where('monthYear', '==', monthYear)
      );
      const snap = await getDocs(q);

      const remainingDocs = snap.docs
        .filter((d) => d.id !== taskId)
        .map((d) => ({ id: d.id, ...d.data() } as TaskItem));

      const sortedRemaining = sortTasksDeterministically(remainingDocs);

      const batch = writeBatch(db);
      batch.delete(doc(db, 'Tasks', taskId));

      sortedRemaining.forEach((task, index) => {
        const correctNumber = index + 1;
        if (task.taskNumber !== correctNumber) {
          batch.update(doc(db, 'Tasks', task.id), {
            taskNumber: correctNumber,
            updatedAt: serverTimestamp(),
          });
        }
      });

      await batch.commit();
      logFirestoreOp('Tasks', 'delete_and_renumber_success', currentAuthUid, taskId);
      return;
    } catch (reindexErr) {
      console.warn('[Firestore Diagnostics] Batch renumber error on delete, falling back to simple delete:', reindexErr);
    }
  }

  // Fallback direct delete
  const docRef = doc(db, 'Tasks', taskId);
  await deleteDoc(docRef);
  logFirestoreOp('Tasks', 'delete_success', currentAuthUid, taskId);
}

// Quick status change
export async function quickUpdateTaskStatus(
  taskId: string,
  newStatus: string
): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  if (!currentAuthUid) throw new Error('Authentication required.');

  logFirestoreOp('Tasks', 'quickUpdateStatus', currentAuthUid, taskId);
  const docRef = doc(db, 'Tasks', taskId);
  await updateDoc(docRef, {
    status: newStatus,
    updatedAt: serverTimestamp(),
  });
}

// Account CRUD
export async function addAccount(
  uid: string,
  accountName: string,
  accountCode: string
): Promise<string> {
  logFirestoreOp('Account_List', 'create', uid);
  const docRef = await addDoc(collection(db, 'Account_List'), {
    ownerUid: uid,
    accountName: accountName.trim(),
    accountCode: accountCode.trim(),
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function updateAccount(
  accountId: string,
  updates: { accountName?: string; accountCode?: string }
): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  logFirestoreOp('Account_List', 'update', currentAuthUid, accountId);
  const docRef = doc(db, 'Account_List', accountId);
  await updateDoc(docRef, updates);
}

export async function deleteAccount(accountId: string): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  logFirestoreOp('Account_List', 'delete', currentAuthUid, accountId);
  const docRef = doc(db, 'Account_List', accountId);
  await deleteDoc(docRef);
}

// Status CRUD
export async function addStatus(
  uid: string,
  statusName: string,
  isDefault: boolean = false
): Promise<string> {
  logFirestoreOp('Status_List', 'create', uid);
  const docRef = await addDoc(collection(db, 'Status_List'), {
    ownerUid: uid,
    statusName: statusName.trim(),
    isDefault,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function deleteStatus(statusId: string): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  logFirestoreOp('Status_List', 'delete', currentAuthUid, statusId);
  const docRef = doc(db, 'Status_List', statusId);
  await deleteDoc(docRef);
}

export async function addCategory(
  uid: string,
  categoryName: string
): Promise<string> {
  logFirestoreOp('Category_List', 'create', uid);
  const docRef = await addDoc(collection(db, 'Category_List'), {
    ownerUid: uid,
    categoryName: categoryName.trim(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function updateCategory(
  categoryId: string,
  categoryName: string
): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  logFirestoreOp('Category_List', 'update', currentAuthUid, categoryId);
  const docRef = doc(db, 'Category_List', categoryId);
  await updateDoc(docRef, {
    categoryName: categoryName.trim(),
    updatedAt: serverTimestamp(),
  });
}

export async function deleteCategory(categoryId: string): Promise<void> {
  const currentAuthUid = auth.currentUser?.uid;
  logFirestoreOp('Category_List', 'delete', currentAuthUid, categoryId);
  const docRef = doc(db, 'Category_List', categoryId);
  await deleteDoc(docRef);
}

/**
 * Initialize workspace for newly registered user.
 * Uses atomic chunked writeBatch operations to eliminate slow sequential requests.
 */
export async function initializeUserWorkspace(uid: string): Promise<void> {
  if (!uid) return;
  logFirestoreOp('Workspace', 'initialize', uid);

  try {
    const qAcc = query(collection(db, 'Account_List'), where('ownerUid', '==', uid));
    const accSnap = await getDocs(qAcc);
    const isNewUser = accSnap.empty;

    const existingAccountNames = new Set(
      accSnap.docs.map((d) => (d.data().accountName || '').toLowerCase().trim())
    );

    // 1. Seed accounts in batches of 100
    const accountsToAdd = DEFAULT_ACCOUNTS.filter(
      (a) => !existingAccountNames.has(a.accountName.toLowerCase().trim())
    );

    if (accountsToAdd.length > 0) {
      const batchSize = 100;
      for (let i = 0; i < accountsToAdd.length; i += batchSize) {
        const chunk = accountsToAdd.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach((acc) => {
          const newDocRef = doc(collection(db, 'Account_List'));
          batch.set(newDocRef, {
            ownerUid: uid,
            accountName: acc.accountName,
            accountCode: acc.accountCode,
            createdAt: serverTimestamp(),
          });
        });
        await batch.commit();
      }
    }

    // 2. Check and seed missing default statuses
    const qStatus = query(collection(db, 'Status_List'), where('ownerUid', '==', uid));
    const statusSnap = await getDocs(qStatus);
    const existingStatuses = new Set(
      statusSnap.docs.map((d) => (d.data().statusName || '').toLowerCase().trim())
    );

    const statusesToAdd = DEFAULT_STATUSES.filter(
      (st) => !existingStatuses.has(st.toLowerCase().trim())
    );

    if (statusesToAdd.length > 0) {
      const batch = writeBatch(db);
      statusesToAdd.forEach((st) => {
        const newDocRef = doc(collection(db, 'Status_List'));
        batch.set(newDocRef, {
          ownerUid: uid,
          statusName: st,
          isDefault: true,
          createdAt: serverTimestamp(),
        });
      });
      await batch.commit();
    }

    // 3. Check and seed missing default categories
    const qCat = query(collection(db, 'Category_List'), where('ownerUid', '==', uid));
    const catSnap = await getDocs(qCat);
    const existingCategories = new Set(
      catSnap.docs.map((d) => (d.data().categoryName || '').toLowerCase().trim())
    );

    const categoriesToAdd = DEFAULT_CATEGORIES.filter(
      (cat) => !existingCategories.has(cat.toLowerCase().trim())
    );

    if (categoriesToAdd.length > 0) {
      const batch = writeBatch(db);
      categoriesToAdd.forEach((cat) => {
        const newDocRef = doc(collection(db, 'Category_List'));
        batch.set(newDocRef, {
          ownerUid: uid,
          categoryName: cat,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      await batch.commit();
    }

    // 4. Seed initial sample tasks for Nov-2026 if this is a brand new user
    if (isNewUser) {
      const sampleTasks = [
        {
          ownerUid: uid,
          taskNumber: 1,
          description: 'Civil Maintenance material...',
          amount: '13,000',
          paymentMode: 'Cash',
          unit: 'Unit-1',
          priority: 'High' as const,
          status: 'Draft Ready',
          expectedDate: '17 Nov 2026',
          accountName: 'Civil Maintenance',
          accountCode: 'ACC-CM101',
          remarks: 'Purchase orders submitted to procurement desk for bricks, cement and joint filler.',
          monthYear: 'Nov-2026',
        },
        {
          ownerUid: uid,
          taskNumber: 2,
          description: 'Air Conditioner maintenance...',
          amount: '125,500',
          paymentMode: 'Bank',
          unit: 'Unit-1',
          priority: 'Low' as const,
          status: 'Done',
          expectedDate: '10 Nov 2026',
          accountName: 'Air Conditioning',
          accountCode: 'ACC-AC205',
          remarks: 'Annual HVAC gas charging, coil cleaning, and thermostat inspection completed.',
          monthYear: 'Nov-2026',
        },
        {
          ownerUid: uid,
          taskNumber: 3,
          description: 'Raw Material transport logistics...',
          amount: '45,000',
          paymentMode: 'Bank',
          unit: 'Unit-1',
          priority: 'Med' as const,
          status: 'Advance Ready',
          expectedDate: '19 Nov 2026',
          accountName: 'Factory Logistics',
          accountCode: 'ACC-FL508',
          remarks: 'Truck freight advance for 3 containers arriving at Chittagong port depot.',
          monthYear: 'Nov-2026',
        },
        {
          ownerUid: uid,
          taskNumber: 4,
          description: 'Fire Extinguisher refill & inspection...',
          amount: '18,500',
          paymentMode: 'Cash',
          unit: 'Unit-2',
          priority: 'High' as const,
          status: 'Pending',
          expectedDate: '22 Nov 2026',
          accountName: 'Safety & Security',
          accountCode: 'ACC-SS602',
          remarks: 'Mandatory safety compliance testing for CO2 and foam cylinders in Unit-2.',
          monthYear: 'Nov-2026',
        },
        {
          ownerUid: uid,
          taskNumber: 5,
          description: 'Packaging cartons bundle delivery...',
          amount: '34,200',
          paymentMode: 'Cash',
          unit: 'Unit-2',
          priority: 'Med' as const,
          status: 'Done',
          expectedDate: '08 Nov 2026',
          accountName: 'Commercial Seal',
          accountCode: 'ACC-CS309',
          remarks: '1,000 corrugated 5-ply cartons received and stacked in warehouse.',
          monthYear: 'Nov-2026',
        },
      ];

      const taskBatch = writeBatch(db);
      sampleTasks.forEach((t) => {
        const newDocRef = doc(collection(db, 'Tasks'));
        taskBatch.set(newDocRef, {
          ...t,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      await taskBatch.commit();
    }

    logFirestoreOp('Workspace', 'initialize_success', uid);
  } catch (err) {
    console.error('[Firestore Diagnostics] Error initializing user workspace:', err);
  }
}
