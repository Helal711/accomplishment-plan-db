# Accomplishment Plan DB - Android Application

Accomplishment Plan DB is a modern native Android application built with Kotlin, Jetpack Compose, and Material Design 3. It allows users to track, plan, and manage daily accomplishment tasks, corporate master accounts, categories, and workflow statuses with real-time Firebase Cloud Firestore synchronization and secure multi-user data isolation.

**Developer:** Md Al Helal Sarkar

---

## Features

- **Multi-User Authentication**: Firebase Authentication with Email/Password and Google Sign-In via Android Credential Manager.
- **Strict Data Isolation**: Every task, master account, and custom status record is scoped to the authenticated user's `ownerUid`.
- **Task Management**:
  - Full CRUD operations: Create, Read, Update, Delete tasks with task numbers, descriptions, amounts (TK), payment modes, factory units, priorities, statuses, expected dates, and remarks.
  - Master Account integration with real-time account code lookup.
  - Priority management (High, Med, Low) with visual indicator chips.
  - Dynamic workflow status tracking with custom statuses.
- **Filtering & Search**:
  - Month/Year selector filter (Nov-2026, Dec-2026, Jan-2027, etc.) with custom month creation.
  - Real-time text search querying description, unit, status, account name, account code, remarks, and task number.
  - Live summary counters (Total Items, Pending Tasks).
- **Master Data Management**:
  - Account Master: Add, edit, and search corporate accounts with assigned codes.
  - Category Manager: Add, edit, and organize task categories.
  - Dynamic Status Manager: Add, configure, and remove custom workflow statuses.
- **Export & Reporting**:
  - CSV export for spreadsheet analysis.
  - Formatted text & table reporting.
- **Adaptive UI & Edge-to-Edge**:
  - Material Design 3 theme with dynamic color support and edge-to-edge system bar insets.
  - Custom vector adaptive launcher icon.

---

## Tech Stack & Architecture

- **UI Framework**: Jetpack Compose & Material 3
- **Language**: Kotlin 2.2+ (Kotlin Coroutines, Flow, StateFlow)
- **Architecture**: MVVM (Model-View-ViewModel) + Repository Pattern
- **Backend & Cloud Database**: Firebase Firestore & Firebase Authentication
- **Build System**: Gradle 9.3 (Kotlin DSL) + Android Gradle Plugin 9.1
- **Target SDK**: Android SDK 36 (Android 16 preview / Android 15 compatible)

---

## License & Author

Developed by Md Al Helal Sarkar.
